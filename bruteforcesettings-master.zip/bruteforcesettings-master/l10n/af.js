OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "Voeg by",
    "Delete" : "Skrap"
},
"nplurals=2; plural=(n != 1);");
