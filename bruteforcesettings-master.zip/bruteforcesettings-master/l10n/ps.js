OC.L10N.register(
    "bruteforcesettings",
    {
    "Delete" : "ړنګول"
},
"nplurals=2; plural=(n != 1);");
