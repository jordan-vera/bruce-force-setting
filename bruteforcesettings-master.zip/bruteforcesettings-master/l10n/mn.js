OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Brute-force тохиргоо",
    "Brute-force IP whitelist" : "Brute-force IP whitelist",
    "Add" : "нэмэх",
    "Delete" : "Устгах"
},
"nplurals=2; plural=(n != 1);");
