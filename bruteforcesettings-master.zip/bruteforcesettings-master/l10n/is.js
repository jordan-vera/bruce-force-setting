OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Stillingar þvingunar",
    "Whitelist IPs" : "Listi með leyfðum IP-tölum",
    "Brute-force IP whitelist" : "Þvinga fram lista með leyfðum IP-tölum (hvítlista)",
    "Add new whitelist" : "Bæta við nýjum lista yfir leyfilegt",
    "Add" : "Bæta við",
    "Delete" : "Eyða"
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
