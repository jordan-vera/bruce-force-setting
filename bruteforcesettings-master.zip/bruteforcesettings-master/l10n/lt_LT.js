OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Slaptažodžių perrinkimo nustatymai",
    "Brute-force IP whitelist" : "Slaptažodžių perrinkimo leidimų sąrašas",
    "Add new whitelist" : "Pridėti naują baltąjį sąrašą",
    "Add" : "Pridėti",
    "Delete" : "Ištrinti"
},
"nplurals=4; plural=(n % 10 == 1 && (n % 100 > 19 || n % 100 < 11) ? 0 : (n % 10 >= 2 && n % 10 <=9) && (n % 100 > 19 || n % 100 < 11) ? 1 : n % 1 != 0 ? 2: 3);");
