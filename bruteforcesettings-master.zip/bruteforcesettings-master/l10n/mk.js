OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "Додади",
    "Delete" : "Избриши"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
