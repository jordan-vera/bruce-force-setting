OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "Derbäimaachen",
    "Delete" : "Läschen"
},
"nplurals=2; plural=(n != 1);");
