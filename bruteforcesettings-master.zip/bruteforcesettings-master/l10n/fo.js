OC.L10N.register(
    "bruteforcesettings",
    {
    "Delete" : "Strika"
},
"nplurals=2; plural=(n != 1);");
