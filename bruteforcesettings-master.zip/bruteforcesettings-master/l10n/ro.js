OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Setări pentru forță-brută",
    "Whitelist IPs" : "IP-uri permise",
    "Brute-force IP whitelist" : "IP-uri permise pentru forță-brută",
    "To whitelist IP ranges from the brute-force protection specify them below. Note that any whitelisted IP can perform authentication attempts without any throttling. For security reasons, it is recommended to whitelist as few hosts as possible or ideally even none at all." : "Pentru a adăuga adrese de IP permise te rog sa le specifici mai jos. De asemenea ține cont ca orice adresa de IP adăugată se va putea autentifica fără nici o restricție. Din pc. de vedere al securității limitează pe cat de mult posibil adresele de IP adăugate, sau, ideal, nu adaugă nici una.",
    "Add new whitelist" : "Adaugă o nouă listă de ip-uri permise",
    "Add" : "Adaugă",
    "Delete" : "Șterge"
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");
