OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "加入",
    "Delete" : "刪除"
},
"nplurals=1; plural=0;");
