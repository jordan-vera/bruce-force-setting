OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Axustes de fuercia bruto",
    "Add" : "Amestar",
    "Delete" : "Desaniciar"
},
"nplurals=2; plural=(n != 1);");
