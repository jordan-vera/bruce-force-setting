OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "قوش",
    "Delete" : "ئۆچۈر"
},
"nplurals=1; plural=0;");
