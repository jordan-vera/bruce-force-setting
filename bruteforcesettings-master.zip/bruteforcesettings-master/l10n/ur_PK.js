OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "شامل کریں",
    "Delete" : "حذف کریں"
},
"nplurals=2; plural=(n != 1);");
