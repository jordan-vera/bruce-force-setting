OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "Lisa",
    "Delete" : "Kustuta"
},
"nplurals=2; plural=(n != 1);");
