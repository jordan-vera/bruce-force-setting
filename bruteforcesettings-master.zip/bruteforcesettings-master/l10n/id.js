OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "Masukkan",
    "Delete" : "Hapus"
},
"nplurals=1; plural=0;");
