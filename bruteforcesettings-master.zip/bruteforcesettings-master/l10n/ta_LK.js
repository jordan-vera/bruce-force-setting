OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "சேர்க்க",
    "Delete" : "நீக்குக"
},
"nplurals=2; plural=(n != 1);");
