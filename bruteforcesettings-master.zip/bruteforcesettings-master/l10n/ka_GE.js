OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Brute-force-ის პარამეტრები",
    "Brute-force IP whitelist" : "Brute-force-ის IP whitelist-ი",
    "Add" : "დამატება",
    "Delete" : "წაშლა"
},
"nplurals=2; plural=(n!=1);");
