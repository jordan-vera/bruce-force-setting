OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "එක් කරන්න",
    "Delete" : "ඉවත් කරන්න"
},
"nplurals=2; plural=(n != 1);");
