OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "Adder",
    "Delete" : "Deler"
},
"nplurals=2; plural=(n != 1);");
