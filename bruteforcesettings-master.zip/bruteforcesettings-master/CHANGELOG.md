# Changelog
All notable changes to this project will be documented in this file.

## 1.5.0
- Made 18 compatible
- Bumped js dependencies
- Updated translations

## 1.4.0
- Made 17 compatible
- Bumped js dependencies
- Updated translations

## 1.3.0
- Made 16 compatible
- Bumped js packages
- Updated translations

## 1.2.0
- Made 15 compatible

## 1.1.0
- Move app to Vue

## 1.0.1

### Added

- Add description text to settings panel
- Improve app description
- Add app screenshot
